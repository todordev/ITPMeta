<?php
/**
 * @package      ITPrism Components
 * @subpackage   ItpMeta
 * @author       Todor Iliev
 * @copyright    Copyright (C) 2010 Todor Iliev <todor@itprism.com>. All rights reserved.
 * @license      http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * ItpMeta is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.controllerform');

/**
 * Url controller class.
 *
 * @package		ITPrism Components
 * @subpackage	ITPMeta
 * @since		1.6
 */
class ItpMetaControllerUrl extends JController {
    
    /**
     * Store edited tag
     *
     */
    public function saveTag(){
        
        JRequest::checkToken() or jexit(JText::_('JINVALID_TOKEN'));
        
        $data   = array();
        $status = 1;
        $msg    = "";
        
        $urlId      = JRequest::getInt('url_id');
        $tagId      = JRequest::getInt('id');
        $content    = JRequest::getVar('content', "", "post", "string", JREQUEST_ALLOWRAW);
        
        try{
            
            if(!$urlId) {
                throw new ItpUserException(JText::_("COM_ITPMETA_ERROR_URL_NOT_EXISTS"), 404);
            }
            $model   = & $this->getModel("Url", "ItpMetaModel");
            $model->saveTag($urlId, $content, $tagId);
            
            $msg     = JText::_("COM_ITPMETA_TAGS_SAVED");
            $data    = array("url_id"=>$urlId);
            
        }catch(ItpUserException $e){
            
            $msg    = $e->getMessage();
            $status = 0;
//            JError::raiseWarning(500, $e->getMessage());
        
        }catch(Exception $e){
            
            $itpSecurity = new ItpSecurity($e);
            $itpSecurity->AlertMe();
            
            JError::raiseError(500, JText::_('ITP_ERROR_SYSTEM'));
            jexit(JText::_('ITP_ERROR_SYSTEM'));
        
        }
    
        ItpResponse::sendJsonMsg($msg, $status, $data);
    }
    
    /**
     * Loads a content
     */
    public function loadTag(){
        
        $tagId  = JRequest::getInt('id');
        
        try{
            
            $model   = $this->getModel("Url", "ItpMetaModel");
            $tag     = $model->getTag($tagId);
            
        }catch(Exception $e){
            
            $itpSecurity = new ItpSecurity($e);
            $itpSecurity->AlertMe();
            
            JError::raiseError(500, JText::_('ITP_ERROR_SYSTEM'));
            jexit(JText::_('ITP_ERROR_SYSTEM'));
        
        }
        
        ItpResponse::sendJsonMsg("All is OK",1,$tag);
    }
    
    /**
     * Loads a content
     */
    public function removeTag(){
        
        $tagId  = JRequest::getInt('id');
        
        try{
            
            $model   = $this->getModel("Url", "ItpMetaModel");
            $tag     = $model->deleteTag($tagId);
            
        }catch(Exception $e){
            
            $itpSecurity = new ItpSecurity($e);
            $itpSecurity->AlertMe();
            
            JError::raiseError(500, JText::_('ITP_ERROR_SYSTEM'));
            jexit(JText::_('ITP_ERROR_SYSTEM'));
        
        }
        
        ItpResponse::sendJsonMsg("All is OK",1,$tag);
    }
    
    /**
     * Load tags
     */
    public function loadTags(){
        
        $urlId  = JRequest::getInt('url_id');

        try{
            
            $model   = $this->getModel("Url", "ItpMetaModel");
            $tags    = $model->getTags($urlId);
            
        }catch(Exception $e){
            
            $itpSecurity = new ItpSecurity($e);
            $itpSecurity->AlertMe();
            
            JError::raiseError(500, JText::_('ITP_ERROR_SYSTEM'));
            jexit(JText::_('ITP_ERROR_SYSTEM'));
        
        }
        
        $html = "";
        if(!empty($tags)) {
           foreach($tags as $tag){
                $html .= '<div class="itpm-tag-item" >
                    <div id="itpmtag_' . $tag->id . '" class="itpm-url-tag"  onclick="document.itpmMeta.loadTag(' .$tag->id.');">
                    <' . htmlspecialchars(JString::substr($tag->content,0,255)) .'...
                    </div>
                    <div class="itpm-tag-actions">
                        <img 
                        src="' .JURI::root().'media/com_itpmeta/images/remove.png" 
                        alt="' . JText::_("ITP_DELETE"). '"
                        onclick="document.itpmMeta.removeTag('.$tag->id.')" 
                        />
                    </div>
                </div>';
           }
        }
        
        echo $html;
    }
    
    /**
     * Cancel operations
     *
     */
    public function cancel(){
        
        $msg = "";
        $this->setRedirect(JRoute::_($this->defaultLink . "&view=urls", false), $msg);
    
    }
    
}