<?php
/**
 * @package      ITPrism Libraries
 * @subpackage   ITPrism Initializators
 * @author       Todor Iliev
 * @copyright    Copyright (C) 2010 Todor Iliev <todor@itprism.com>. All rights reserved.
 * @license      http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * ITPrism Library is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

jimport('joomla.error.log');

if(!defined("ITPMETA_COMPONENT_ADMINISTRATOR")) {
    define("ITPMETA_COMPONENT_ADMINISTRATOR", JPATH_ROOT . DS. "administrator" . DS . "components" . DS ."com_itpmeta");
}

// Register ITPrism library
JLoader::register("ItpResponse",ITPMETA_COMPONENT_ADMINISTRATOR . DS . "libraries" . DS . "itp". DS . "itpresponse.php");
JLoader::register("ItpSecurity",ITPMETA_COMPONENT_ADMINISTRATOR . DS . "libraries" . DS . "itp". DS . "itpsecurity.php");
JLoader::register("ItpException",ITPMETA_COMPONENT_ADMINISTRATOR . DS . "libraries" . DS . "itp". DS . "exceptions" . DS . "itpexception.php");
JLoader::register("ItpUserException",ITPMETA_COMPONENT_ADMINISTRATOR . DS . "libraries" . DS . "itp". DS . "exceptions" . DS . "itpuserexception.php");

// Register Component libraries
JLoader::register("ItpMetaVersion",ITPMETA_COMPONENT_ADMINISTRATOR . DS . "libraries" . DS . "itpmeta". DS . "itpmetaversion.php");

// Register Component helpers
JLoader::register("ItpMetaHelper",ITPMETA_COMPONENT_ADMINISTRATOR . DS . "helpers" . DS . "itpmetahelper.php");