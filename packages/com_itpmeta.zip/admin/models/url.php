<?php
/**
 * @package      ITPrism Components
 * @subpackage   ITPMeta
 * @author       Todor Iliev
 * @copyright    Copyright (C) 2010 Todor Iliev <todor@itprism.com>. All rights reserved.
 * @license      http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * ITPMeta is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// no direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.modeladmin');

/**
 * It is a project model
 * 
 * @author Todor Iliev
 */
class ItpMetaModelUrl extends JModelAdmin {
    
    /**
     * @var     string  The prefix to use with controller messages.
     * @since   1.6
     */
    protected $text_prefix = 'COM_ITPMETA';
    
    /**
     * Constructor.
     *
     * @param   array   $config An optional associative array of configuration settings.
     *
     * @see     JController
     * @since   1.6
     */
    public function __construct($config = array()){
        parent::__construct($config);
        
    }
    
    /**
     * Returns a reference to the a Table object, always creating it.
     *
     * @param   type    The table type to instantiate
     * @param   string  A prefix for the table class name. Optional.
     * @param   array   Configuration array for model. Optional.
     * @return  JTable  A database object
     * @since   1.6
     */
    public function getTable($type = 'url', $prefix = 'ItpMetaTable', $config = array()){
        return JTable::getInstance($type, $prefix, $config);
    }
    
    /**
     * Method to get the record form.
     *
     * @param   array   $data       An optional array of data for the form to interogate.
     * @param   boolean $loadData   True if the form is to load its own data (default case), false if not.
     * @return  JForm   A JForm object on success, false on failure
     * @since   1.6
     */
    public function getForm($data = array(), $loadData = true){
        // Initialise variables.
        $app = JFactory::getApplication();
        
        // Get the form.
        $form = $this->loadForm('com_itpmeta.url', 'url', array('control' => 'jform', 'load_data' => $loadData));
        if(empty($form)){
            return false;
        }
        
        return $form;
    }
    
    /**
     * Method to get the data that should be injected in the form.
     *
     * @return  mixed   The data for the form.
     * @since   1.6
     */
    protected function loadFormData(){
        // Check the session for previously entered form data.
        $data = JFactory::getApplication()->getUserState('com_itpmeta.edit.url.data', array());
        
        if(empty($data)){
            $data = $this->getItem();
        }
        
        return $data;
    }
    
    /**
     * Save tag into the DB
     * 
     * @param $tagId       Tag ID
     * @param $content     A tag in HTML code style
     * @param $urlId     An URL id
     * 
     */
    public function saveTag($urlId, $content, $tagId = null){
        
        if(!empty($urlId) AND !empty($content)) {

            $row = $this->getTable('Tag', 'ItpMetaTable');
            $row->load($tagId);
            
            $row->set("content", $content);
            $row->set("url_id", $urlId);
            
            if(!$row->store()) {
                throw new ItpException($row->getError(), 500);
            }
        }
    
    }
    
    /**
     * Delete records from table "tags"
     *
     * @param array $tagId
     * @exception ItpException
     */
    public function deleteTag($tagId){
        
        if(!$tagId){
            throw new ItpException(JText::_('ITP_ERROR_INVALID_ITEMS'), 404);
        }
        
        $row = $this->getTable('Tag', 'ItpMetaTable');
        $row->load($tagId);
        
        if(!$row->delete($tagId)) {
            throw new ItpException($row->getError(), 500);
        }
        
        return $row;
    
    }
    
    /**
     * Get tags from DB
     *
     * @param       integer $urlId
     * @exception   ItpException
     * @return      array A list with tag objects
     */
    public function getTags($urlId){
        
        $results = array();
        if(!$urlId){
            return $results;
        }
        
        // Delete categories 
        $query = "
            SELECT 
                *  
            FROM 
                 `#__itpm_tags`
            WHERE   
                 `url_id`=" . (int)$urlId;
        
        $this->_db->setQuery($query);
        $result = $this->_db->loadObjectList();
        
        if ($this->_db->getErrorNum() != 0) {
            throw new ItpException($this->_db->getErrorMsg(), 500);
        }
        
        return $result;
    
    }
    
    /**
     * Gets a tag
     *
     * @param       array $tagId
     * @exception   ItpException
     */
    public function getTag($tagId){
        
        if(!$tagId){
            throw new ItpException(JText::_('ITP_ERROR_INVALID_ITEMS'), 404);
        }
        
        // Delete categories 
        $query = "
            SELECT 
                *  
            FROM 
                 `#__itpm_tags` 
            WHERE   
                 `id`=" . (int)$tagId;
        
        $this->_db->setQuery($query);
        $result = $this->_db->loadObject();
        
        if ($this->_db->getErrorNum() != 0) {
            throw new ItpException($this->_db->getErrorMsg(), 500);
        }
        
        return $result;
    
    }
    
    public function delete(&$pks) {
        
        JArrayHelper::toInteger($pks);
        if(!$pks) {
            throw new ItpException(JText::_('ITP_ERROR_INVALID_ITEMS'), 404);
        }
        
        $query = "
            DELETE
            FROM
                `#__itpm_tags`
            WHERE
                `url_id` IN ('" . implode(",", $pks) . "')";
        
        $this->_db->setQuery($query);
        $results = $this->_db->loadObjectList();
        
        if ($this->_db->getErrorNum() != 0) {
            throw new ItpException($this->_db->getErrorMsg(), 500);
        }
        
        parent::delete($pks);
    }
    
}