<?php
/**
 * @package      ITPrism Components
 * @subpackage   ITPMeta
 * @author       Todor Iliev
 * @copyright    Copyright (C) 2010 Todor Iliev <todor@itprism.com>. All rights reserved.
 * @license      http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * ITPMeta is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// no direct access
defined('_JEXEC') or die();

jimport('joomla.html.pane');
jimport('joomla.application.component.view');

class ItpMetaViewUrl extends JView {
    
    protected $state;
    protected $item;
    protected $form;
    
    /**
     * Display the view
     */
    public function display($tpl = null){
        $this->state = $this->get('State');
        $this->item = $this->get('Item');
        $this->form = $this->get('Form');

        // Check for errors.
        if(count($errors = $this->get('Errors'))){
            JError::raiseError(500, implode("\n", $errors));
            return false;
        }
        
        $model = $this->getModel();
        $this->tags = $model->getTags($this->item->id);
        
        $this->addToolbar();
        $this->addScripts();
        parent::display($tpl);
    }
    
    /**
     * Add the page title and toolbar.
     *
     * @since   1.6
     */
    protected function addToolbar(){
        
        JRequest::setVar('hidemainmenu', true);
        
        // Set toolbar items for this page
        if(!$this->item->id) {
            $this->assign("title", JText::_('COM_ITPMETA_URL_ADD'));
            JToolBarHelper::title( JText::_('COM_ITPMETA_URL_ADD') , 'itp-new-url' );
        } else {
            $this->assign("title", JText::_('COM_ITPMETA_URL_EDIT'));
            JToolBarHelper::title( JText::_('COM_ITPMETA_URL_EDIT') , 'itp-edit-url' );
        }
        JToolBarHelper::apply('url.apply', 'JTOOLBAR_APPLY');
        JToolBarHelper::save('url.save', 'JTOOLBAR_SAVE');
    
        JToolBarHelper::custom('url.save2new', 'save-new.png', 'save-new_f2.png', 'JTOOLBAR_SAVE_AND_NEW', false);
        
        if(empty($this->item->id)){
            JToolBarHelper::cancel('url.cancel', 'JTOOLBAR_CANCEL');
        }else{
            JToolBarHelper::cancel('url.cancel', 'JTOOLBAR_CLOSE');
        }
        
    }

    protected function addScripts() {
        
        // Add JavaScript to the page
        $this->document->addScript(JURI::root() . 'media/com_itpmeta/itpmeta.js');
        
        $js = "window.addEvent('domready', function() {
            document.itpmMeta = new ItpMeta('itpm-content');
            document.itpMetaTagsId = '';
            
            document.id('tag-form').addEvent('submit', function(e){ 
                e.preventDefault();
                document.itpmMeta.saveTag(); 
                
            });
            
            document.id('itpm-reset-btn').addEvent('click', function(e){
                document.id('itp-tag-id').set('value','');
            });
            
            document.id('itpm-content').set('value','');
            document.id('itp-tag-id').set('value','');
            
        });";
        
        $this->document->addScriptDeclaration($js);
        
    }
    
}