<?php
/**
 * @package      ITPrism Components
 * @subpackage   ITPMeta
 * @author       Todor Iliev
 * @copyright    Copyright (C) 2010 Todor Iliev <todor@itprism.com>. All rights reserved.
 * @license      http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * ITPMeta is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

/**
 * It is the component helper class
 *
 */
class ItpMetaHelper {
	
    /**
     * Load Tags for specefic url
     * 
     * @param string    $url
     * @return array    Tags
     */
    public static function getTags($url, $onlyPublished = true){
        
        // Initialize some variables
        $db = & JFactory::getDBO();
 
        $tableUrls          = $db->nameQuote("#__itpm_urls");
        $columnUrlId        = $db->nameQuote("id");
        $columnUrl          = $db->nameQuote("url");
        
        $tableTags          = $db->nameQuote("#__itpm_tags");
        $columnTagsUrlId    = $db->nameQuote("url_id");   
        
        $query = "
            SELECT 
                $tableTags.*
            FROM 
                $tableTags
            INNER JOIN
                $tableUrls 
            ON
                $tableUrls.$columnUrlId = $tableTags.$columnTagsUrlId
            WHERE 
               $tableUrls.$columnUrl = " . $db->Quote( $url );

        if($onlyPublished){
           $query .= " AND $tableUrls.published=1"; 
        }
        
        $db->setQuery($query);
        return $db->loadObjectList();
        
    }
   
}