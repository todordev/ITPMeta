ITPMeta for Joomla! 
==========================
( Version 3.0 )
--------------------------

It is a Joomla! extension that puts meta tags into the site code. The component provides a list with predefined and popular meta tags. There are Open Graph,  Facebook, Google and other semantic tags.

Changelog
---------

v3.0
-----------
* Ported to Joomla! 2.5
* Added global tags
* Added a new video tag - og:secure_url
* Added a locale tags - og:locale, og:locale:alternate
* Improved

v2.2
-----------
* Added Open Graph URL tag
* Improved

v2.1
-----------
* Fixed a bug in the plugin